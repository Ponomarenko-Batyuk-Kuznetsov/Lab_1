package com.company;

public class Division {
    //cоздание конструктора
}

interface Division{
    //реализация метода
}

