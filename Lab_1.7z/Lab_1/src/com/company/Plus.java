package com.company;

public class Plus {
    //создание конструктора
}

interface Plus{
    //реализация метода
}
