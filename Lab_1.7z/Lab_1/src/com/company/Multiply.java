package com.company;

public class Multiply {
    //cоздание конструктора
}

interface Multiply{
    //реализация метода
}
