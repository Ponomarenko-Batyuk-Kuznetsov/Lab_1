package com.company;

public class Minus {
    //создание конструктора
}

interface Minus{
    //реализация метода
}